window.open('https://releva.nz', '_blank'); 
