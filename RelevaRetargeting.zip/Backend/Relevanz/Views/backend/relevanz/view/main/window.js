//{namespace name="backend/wave_cdn/main"}
//{block name="backend/wave_cdn/view/main/window"}
//{/block}
