window.open('http://www.releva.nz', '_blank'); 
