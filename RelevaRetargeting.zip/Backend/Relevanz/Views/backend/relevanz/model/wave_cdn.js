createItems: function() {
/*	var me = this, items = [], item, config,
		associations, fields, field, keys;

	return false;*/
/*	if (!me.fireEvent(me.eventAlias + '-before-create-items', me, items)) {
		return false;
	}

	//iterate all defined field sets. If no field set configured, the component is used for none model fields.
	Ext.each(me.getConfig('fieldSets'), function(fieldSet) {
		...
		item = me.createModelFieldSet(me.record.$className, fields, fieldSet);
		items.push(item);
	});

	...

	me.fireEvent(me.eventAlias + '-after-create-items', me, items);

	return items;*/
},
